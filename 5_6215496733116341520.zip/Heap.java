package dsaproject;

public class Heap {
    Task heap[] = new Task[100];
    int size = 0;

    public void insert(Task t) {
        heap[size] = t;
        int i = size;
        size++;

        while (i > 0 && heap[(i - 1) / 2].priority < heap[i].priority) {
            Task temp = heap[i];
            heap[i] = heap[(i - 1) / 2];
            heap[(i - 1) / 2] = temp;
            i = (i - 1) / 2;
        }
    }

    void heapifyDown(Task arr[], int i, int n) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left].priority > arr[largest].priority)
            largest = left;

        if (right < n && arr[right].priority > arr[largest].priority)
            largest = right;

        if (largest != i) {
            Task temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;

            heapifyDown(arr, largest, n);
        }
    }

    public void heapSort() {
        if (size == 0) {
            System.out.println("No tasks to sort!");
            return;
        }

        Task tempArr[] = new Task[size];
        for (int i = 0; i < size; i++) {
            tempArr[i] = heap[i];
        }

        int n = size;

        for (int i = n / 2 - 1; i >= 0; i--) {
            heapifyDown(tempArr, i, n);
        }

        for (int i = n - 1; i >= 0; i--) {
            Task temp = tempArr[0];
            tempArr[0] = tempArr[i];
            tempArr[i] = temp;

            heapifyDown(tempArr, 0, i);
        }
    }

    public Task getMax() {
        if (size == 0) return null;
        return heap[0];
    }
}