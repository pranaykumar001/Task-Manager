package dsaproject;

public class Stack {
    Task top = null;

    public void push(Task t) {
        t.next = top;
        top = t;
    }

    public Task pop() {
        if (top == null) return null;
        Task temp = top;
        top = top.next;
        return temp;
    }

    public boolean isEmpty() {
        return top == null;
    }
}