package dsaproject;

import java.util.Scanner;

public class ToDoList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        TaskManager tm = new TaskManager();
        TaskManagerFile tmf = new TaskManagerFile();

        System.out.println("Loading previous data...");
        tmf.loadFromFile(tm); 

        boolean flag = true;

        do {
            System.out.println("\n1.Add 2.View 3.Complete 4.Undo 5.Process");
            System.out.println("6.Priority 7.Search 8.Sort Priority 9.Sort Deadline 10.Exit");

            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.print("ID:");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Name:");
                    String name = sc.nextLine();

                    System.out.print("Priority:");
                    int p = sc.nextInt();

                    System.out.print("Deadline:");
                    int d = sc.nextInt();

                    tm.addTask(id, name, p, d);
                    break;

                case 2:
                    tm.viewTasks();
                    break;

                case 3:
                    System.out.print("ID:");
                    tm.completeTask(sc.nextInt());
                    break;

                case 4:
                    tm.undoTask();
                    break;

                case 5:
                    tm.processTask();
                    break;

                case 6:
                    tm.showHighestPriority();
                    break;

                case 7:
                    System.out.print("ID:");
                    tm.searchTask(sc.nextInt());
                    break;

                case 8:
                    tm.sortByPriority();
                    break;

                case 9:
                    tm.sortByDeadline();
                    break;

                case 10:
                    flag = false;
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid!");
            }
        } while (flag);

        sc.close();
    }
}