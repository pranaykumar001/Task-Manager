package dsaproject;

public class TaskManager {
    Task head = null;

    TaskManagerFile tmf = new TaskManagerFile();
    Stack stack = new Stack();
    Queue queue = new Queue();
    HashTable hash = new HashTable();
    Heap heap = new Heap();

    public void addTask(int id, String name, int priority, int deadline) {
        Task newTask = new Task(id, name, priority, deadline);

        if (head == null) {
            head = newTask;
        } else {
            Task temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newTask;
        }

        queue.enqueue(newTask);
        hash.insert(newTask);
        heap.insert(newTask);

        tmf.saveToFile(head);

        System.out.println("Task Added!");
    }

    public void viewTasks() {
        Task temp = head;

        if (temp == null) {
            System.out.println("No tasks.");
            return;
        }

        while (temp != null) {
            System.out.println("ID:" + temp.id + " Name:" + temp.name +
                    " Priority:" + temp.priority + " Deadline:" + temp.deadline);
            temp = temp.next;
        }
    }

    public void completeTask(int id) {
        Task temp = head, prev = null;

        while (temp != null && temp.id != id) {
            prev = temp;
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Not found!");
            return;
        }

        if (prev == null) head = temp.next;
        else prev.next = temp.next;

        stack.push(temp);
        hash.delete(id);

        tmf.saveToFile(head); // ✅ FIX

        System.out.println("Completed!");
    }

    public void undoTask() {
        if (stack.isEmpty()) {
            System.out.println("Nothing to undo!");
            return;
        }

        Task t = stack.pop();
        t.next = head;
        head = t;

        queue.enqueue(t);
        hash.insert(t);
        heap.insert(t);

        tmf.saveToFile(head);

        System.out.println("Undo done!");
    }

    public void processTask() {
        if (queue.isEmpty()) {
            System.out.println("Queue empty!");
            return;
        }

        Task t = queue.dequeue();
        System.out.println("Processing: " + t.name);
    }

    public void showHighestPriority() {
        Task t = heap.getMax();
        if (t == null)
            System.out.println("No tasks!");
        else
            System.out.println("Highest Priority: " + t.name);
    }

    public void searchTask(int id) {
        Task t = hash.search(id);

        if (t == null)
            System.out.println("Not found!");
        else
            System.out.println("Found: " + t.name);
    }

    public void sortByPriority() {
        if (head == null) return;

        for (Task i = head; i != null; i = i.next) {
            for (Task j = i.next; j != null; j = j.next) {
                if (i.priority < j.priority) {

                    int tempId = i.id;
                    i.id = j.id;
                    j.id = tempId;

                    String tempName = i.name;
                    i.name = j.name;
                    j.name = tempName;

                    int tempP = i.priority;
                    i.priority = j.priority;
                    j.priority = tempP;

                    int tempD = i.deadline;
                    i.deadline = j.deadline;
                    j.deadline = tempD;
                }
            }
        }

        System.out.println("Sorted by Priority!");
    }

    public void sortByDeadline() {
        if (head == null) return;

        for (Task i = head; i != null; i = i.next) {
            for (Task j = i.next; j != null; j = j.next) {
                if (i.deadline > j.deadline) {
                    int temp = i.deadline;
                    i.deadline = j.deadline;
                    j.deadline = temp;
                }
            }
        }

        System.out.println("Sorted by Deadline!");
    }
}