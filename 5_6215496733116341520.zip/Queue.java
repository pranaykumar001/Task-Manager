package dsaproject;

public class Queue {
    Task front = null, rear = null;

    public void enqueue(Task t) {
        t.next = null;

        if (rear == null) {
            front = rear = t;
        } else {
            rear.next = t;
            rear = t;
        }
    }

    public Task dequeue() {
        if (front == null) return null;

        Task temp = front;
        front = front.next;

        if (front == null) rear = null;

        return temp;
    }

    public boolean isEmpty() {
        return front == null;
    }
}