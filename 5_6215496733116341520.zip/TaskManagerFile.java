package dsaproject;

import java.io.*;

public class TaskManagerFile {

    public void loadFromFile(TaskManager tm) {
        try {
            FileReader fr = new FileReader("taskManager.txt");
            BufferedReader br = new BufferedReader(fr);
            String line;

            while ((line = br.readLine()) != null) {
                String parts[] = line.split(",");

                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                int priority = Integer.parseInt(parts[2]);
                int deadline = Integer.parseInt(parts[3]);

                tm.addTask(id, name, priority, deadline);
            }

            br.close();
        } catch (IOException io) {
            System.out.println("Error loading file!");
            io.printStackTrace();
        }
    }

    public void saveToFile(Task head) {
        try {
        		FileWriter fw = new FileWriter("taskManager.txt");
            BufferedWriter bw = new BufferedWriter(fw);

            Task temp = head;

            while (temp != null) {
                bw.write(temp.id + "," + temp.name + "," +
                        temp.priority + "," + temp.deadline);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();
        } catch (IOException io) {
            System.out.println("Error saving file!");
            io.printStackTrace();
        }
    }
}