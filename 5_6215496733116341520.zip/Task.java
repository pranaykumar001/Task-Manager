package dsaproject;

public class Task {
    int id;
    String name;
    int priority;
    int deadline; 

    Task next;

    public Task(int id, String name, int priority, int deadline) {
        this.id = id;
        this.name = name;
        this.priority = priority;
        this.deadline = deadline;
        this.next = null;
    }
}