package dsaproject;

public class HashTable {
    Task arr[] = new Task[100];

    public void insert(Task t) {
        int index = t.id % 100;
        arr[index] = t;
    }

    public Task search(int id) {
        int index = id % 100;
        return arr[index];
    }

    public void delete(int id) {
        int index = id % 100;
        arr[index] = null;
    }
}