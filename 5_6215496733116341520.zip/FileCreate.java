package dsaproject;
import java.io.*;
public class FileCreate {
	public static void main(String []args)
	{
		File fc = null;
		try
		{
			fc = new File("taskManager.txt");
			if(fc.createNewFile())
			{
				System.out.println("File created with the name "+fc.getName());
			}
			else
			{
				System.out.println("File is already created in the absolute path "+fc.getAbsolutePath());
			}
		}
		catch(IOException io)
		{
			System.out.println("File cannot be created");
			io.printStackTrace();
		}
	}
}
